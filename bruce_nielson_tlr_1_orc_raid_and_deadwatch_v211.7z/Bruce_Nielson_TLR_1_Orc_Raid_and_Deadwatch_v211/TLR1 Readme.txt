The Light Reborn (1): Orc Raid / Deadwatch v 2.0x
For levels 1-3

The Light Reborn is a role playing adventure told through the medium of the computer. Think of it as a fantasy novel in which you take part.


For Single and Multiplayer

A shadow has fallen across the world of Harthe. The arrival of a man, named Samuel, claiming to be a Veranite -- the lost race of kings blessed by the Creator of Harthe with divine power -- causes a stir in the country of Anvid. Could he really be a Veranite? Does he serve the Light, as he says, or is he a deceiver? 

Samuel gathers heroes across the land to do the will of the Virtues -- the spirits of good that he claims to talk to. You are one such hero. But the power of the Dark does not stand still. Who can resist it?

This adventure is "DM-friendly." It alerts DMs of particular plot points and have the DM helper available to assist.

To learn more about The Light Reborn, please visit:
http://www.prism.net/bnielson/LightReborn.html

Credits:
Designed and Developed by: Bruce Nielson (bnielson@prism.net)
DM Helper: Dopple & Jhenne & Splith & Robert Bernavich & Archaegeo
A simple game of tag: hahnsoo
Fishing: Nouny 
Beta Testing: Christine Wheeler and Hubersk


We are always looking for more team members. If you'd like to join the team email Bruce at bnielson@prism.net

A note on The Light Reborn Series:
The Light Reborn is a PnP campaign game that was created original for T&T and GURPS. I converted it over to D&D 3E for Neverwinter Nights. The game world is somewhat different that your standard D&D game world, however. If you want to get the most out of your game experience, you should visit the web site listed above and read up on the world. There are also in game books that contain much of the background info that your character would realistically know. However, there are a few points that should probably be briefly covered here:
1) Humans are the dominant race. If possible, please play a human. The game will handle other races, but you get the best gaming experience if you play a human.
2) The adventure assumes that you are a good aligned character. You can play any alignment you wish, of course, but you'll get the best experience by playing good aligned.
3) Clerics and Paladins get their powers from Samuel Meladon, not from some god. If you play a Paladin or Cleric, there is no point in naming a deity as none of the D&D dieties exist in this world. There is, in fact, only one Creator in this world - not a patheon of gods.
These are just a few tips to help you with the game experience.

Another note: This was my very first module. I learned a lot by making it and improved in future mods. I am still quite proud of this module, though it simply doesn't compare to my later work. If you only have time to play one of my modules, I recommend skipping this one and playing part 3 - which is my best work.

Final note: I created this series to play with people on-line on NeverwinterConnections (www.neverwinterconnections.com). I like to DM the games personally. However, I also wanted to bring my campaign world to a larger audience, so I fully scripted my modules to work in single player as well. This turned out to have the added advantage of allowing me to split parties up without fear of the game coming to a halt. I rather like the combination of DM play mixed with heavy scripting. To assit DM's I've added the ability to trigger plot points to the DM wand that is automatically given to all DMs upon entering. You can use this to activate key plot points.

Changes to Version 2.03: Fixed the XP problem in multiplayer games. Added some additional safe rest areas to the orc caves.

Changes to Version 2.04: Fixed problem with henchmen disappearing if you are using a higher level character than recommended.

Changes to Version 2.05: Fixed problem with henchman not respawning at the respawn point that broke due to Bioware changes in latest patch.

Changes to Version 2.06: Made additional fixes for problems with henchmen due to BioWare breaking them in version 1.62. However, there are still problems. I haven't found a universal fix yet.

Changes to Version 2.08: Henchmen now "listen" to you again. DMFI wands added to the module.

Changes to Version 2.09: I broke some things with the DMFI wands and had to fix the script.

Changes to Version 2.10: Commoners are back to being cowardly again. Bioware broke this a while back and I couldn't figure out how to fix it until now.

Changes to Version 2.11: I fixed the "Broc freeze" problem. There are a few other minor changes in things that broke with the DMFI wands being added or from the XP2 update.

Thanks,

Bruce Nielson