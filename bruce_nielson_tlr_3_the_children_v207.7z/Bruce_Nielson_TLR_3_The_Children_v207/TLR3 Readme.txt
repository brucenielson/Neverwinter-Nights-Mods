The Light Reborn (3): The Children - Version 2.0x
For levels 6-8

Single and Multiplayer

A well balance party of 3 to 6 players could play starting out at level 6. A single player would probably want to be at least level 7. If you don't like to reload from time to time then you might want to try it at level 8 single player to make it easier. This game will take 3 or 6 hours to play through.

Background:
A shadow has fallen across the world of Harthe. The arrival of a man, named Samuel, claiming to be a Veranite -- the lost race of kings blessed by the Creator of Harthe with divine power -- causes a stir in the country of Anvid. Could he really be a Veranite? Does he serve the Light, as he says, or is he a deceiver? 

Samuel gathers heroes across the land to do the will of the Virtues -- the spirits of good that he claims to talk to. You are one such hero. But the power of the Dark does not stand still. Who can resist it?

Your on your way to Anvid city to hunt down a Servant of Solanor named Tarnn. Having just defeated the Death Trap and proven your friendship to The Children (i.e. elves) by removing their bugbear infestation you now have been granted access to their realm. Samuel and friends join you as you pass into the realm of The Children - the first non-elves in centuries!

This adventure is "DM-friendly." It alerts DMs of particular plot points and has the DM helper available to assist. Plot points can be activated via this wand.

To learn more about The Light Reborn, please visit:
http://www.prism.net/bnielson/LightReborn.html

Credits:
Designed and Developed by: Bruce Nielson (bnielson@prism.net)
Jasperre's Improved AI by Jasperre
Testing: Christine Wheeler, Scot Huber, Rob Foster, Rob Baker, DarkHand, SleepingDog
Camera System: EG_Gestalt 
DM Helper: Dopple & Jhenne & Splith & Robert Bernavich & Archaegeo
Complex Structures: Red Golem

We are always looking for more team members. If you'd like to join the team email Bruce at bnielson@prism.net

A note on The Light Reborn Series:
The Light Reborn is a PnP campaign game that was created original for T&T and GURPS. I converted it over to D&D 3E for Neverwinter Nights. The game world is somewhat different that your standard D&D game world, however. If you want to get the most out of your game experience, you should visit the web site listed above and read up on the world. There are also in-game books that contain much of the background info that your character would realistically know. However, there are a few points that should probably be briefly covered here:
1) Humans are the dominant race. If possible, please play a human. The game will handle other races, but you get the best gaming experience if you play a human.
2) The adventure assumes that you are a good aligned character. You can play any alignment you wish, of course, but you'll get the best experience by playing good aligned.
3) Clerics and Paladins get their powers from Samuel Meladon, not from some god. If you play a Paladin or Cleric, there is no point in naming a deity as none of the D&D dieties exist in this world. There is, in fact, only one Creator in this world - not a patheon of gods.
These are just a few tips to help you with the game experience.

Another note: TLR 1 was story and exploration oriented. TLR 2 was puzzle, trick, trap oriented. TLR 3 was Final Fantasy-esque (i.e. *really* story oriented.) TLR 4 is meant to be action oriented. I'm trying to create adventures of all types and put them into a single campaign setting. Enjoy.


WARNING - Contains SPOILERS!
Extras: There is a multiplayer only quest in this game. The cave near Mauglin ruins. It requires at least two PCs to get the doors open using the levers. You'll need a whole party for what's behind those doors. This quest only becomes active if you are playing multiplayer. Look for a woman near the entrance to the Mauglin area. 
Changes for version 2.00:
Henchmen can now level up to level 8 and they will have the same level as the player (instead of one level lower.) This will make the game easier in single player.

I added a multiplayer side quest that only shows up in multiplayer games. I like side quests that require the team to work together. This is a short one to add to the fun of the multiplayer experience. 

I changed the "exposition" dialog in the game to have a "[summarize]" option. This cuts back on the opening dialogs in the game. I meant this to make multiplayer more enjoyable - but some people will like it for single player as well. This addresses the "too much dialog" issue that some people had. After the exposition is over, you just have to live with the dialog - but it's generally shorter by then.

I added better hints on how to solve the nymph cove side quest - including hints in the journal. Apparently many people never played the side quest because it wasn't obvious enough. There is not much to this side quest, but it's a fun diversion - especially in multiplayer. It's a good opportunity to role play.

To enhance the single player experience, I added one major conversation for each of the 3 major henchmen. All three have to do with the mystery. All three give a bit more background info on the henchmen themselves. I felt this fleshed out the henchmen quite a bit.

I reimplemented Jasperre's AI in the portal battle. This will make the mages a bit tougher and more interesting. I cached those scripts to keep it from getting bogged down.

I also fixed various minor bugs found.

Changes for Version 2.01:
Fixed the problem with XP for multiplayer games.

Changes to Version 2.02: Fixed problem with henchman not respawning at the respawn point that broke due to Bioware changes in latest patch. I also added some "tails" and "wings" where appropriate.

Changes to Version 2.03: Fixed problem with henchmen not responding to commands.

Changes to Version 2.05: Added DMFI wands to the module.

Changes to Version 2.06: I broke some things with the DMFI wands and had to fix the script.

Changes to Version 2.07: I fixed the henchmen to not die permenantly. Fixed a few other minor things I can't remember. Fixed the face object command.

Thanks,

Bruce Nielson