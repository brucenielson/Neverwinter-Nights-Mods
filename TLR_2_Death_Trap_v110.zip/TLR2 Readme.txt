The Light Reborn (2): Death Trap - Version 1.0x
For levels 4-6

The Light Reborn is a role playing adventure told through the medium of the computer. Think of it as a fantasy novel in which you take part.

Single and Multiplayer

I recommend level 5 at least for single player.

A shadow has fallen across the world of Harthe. The arrival of a man, named Samuel, claiming to be a Veranite -- the lost race of kings blessed by the Creator of Harthe with divine power -- causes a stir in the country of Anvid. Could he really be a Veranite? Does he serve the Light, as he says, or is he a deceiver? 

Samuel gathers heroes across the land to do the will of the Virtues -- the spirits of good that he claims to talk to. You are one such hero. But the power of the Dark does not stand still. Who can resist it?

This time Samuel sends you on a mission to Anvid City to hunt down Tarnn, the Servant of Solanor. But can you survive Shadowglen Woods to get there?

This adventure is "DM-friendly." It alerts DMs of particular plot points and has the DM helper available to assist.

To learn more about The Light Reborn, please visit:
http://www.prism.net/bnielson/LightReborn.html

Credits:
Designed and Developed by: Bruce Nielson (bnielson@prism.net)
Editing of Text: Sayna Phare
DM Helper: Dopple & Jhenne & Splith & Robert Bernavich & Archaegeo
Teleporting Chest Room: from The Book of Challenges (from Wizard's of the Coast)
Riddle: by Mark Anthony (from Dragon Magazine - Issue 175 "The Riddle!")

This is the "Deathtrap" scenario and is part 2 of the series.

We are always looking for more team members. If you'd like to join the team email Bruce at bnielson@prism.net

A note on The Light Reborn Series:
The Light Reborn is a PnP campaign game that was created original for T&T and GURPS. I converted it over to D&D 3E for Neverwinter Nights. The game world is somewhat different that your standard D&D game world, however. If you want to get the most out of your game experience, you should visit the web site listed above and read up on the world. There are also in game books that contain much of the background info that your character would realistically know. However, there are a few points that should probably be briefly covered here:
1) Humans are the dominant race. If possible, please play a human. The game will handle other races, but you get the best gaming experience if you play a human.
2) The adventure assumes that you are a good aligned character. You can play any alignment you wish, of course, but you'll get the best experience by playing good aligned.
3) Clerics and Paladins get their powers from Samuel Meladon, not from some god. If you play a Paladin or Cleric, there is no point in naming a deity as none of the D&D dieties exist in this world. There is, in fact, only one Creator in this world - not a patheon of gods.
These are just a few tips to help you with the game experience.

Another note: I created a story oriented adventure for TLR 1, so this time around I wanted a tricks, traps, and puzzles oriented adventure. The story is downplayed in favor of the tricks. But don't worry, the story picks up again in full force in TLR 3.

About version 1.05 - I attempted to fix the problems with the secret doors and fixed the multiplayer XP problem.

Changes to Version 1.06: Fixed problem with henchman not respawning at the respawn point that broke due to Bioware changes in latest patch.

Changes to Version 1.08: Fixed henchmen to "listen" again. (BioWare broke this by changing their scripts.) Added DMFI Wands to module.

Changes to Version 1.09: I broke some things with the DMFI wands and had to fix the script.

Changes to Version 1.10: I fixed the henchmen dying permenantly. Fixed the face object command. Changed the safe rest area to be easier to get into. Put a warning on the multiplayer only quest so single players won't bang their head against it for hours only to write to me to find out the quest is both optional and impossible.

Thanks,

Bruce Nielson

