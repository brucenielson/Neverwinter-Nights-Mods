The Light Reborn (4): Night - Version 1.0x
For levels 7-9

The Light Reborn is a role playing adventure told through the medium of the computer. Think of it as a fantasy novel in which you take part.

Single and Multiplayer

A well balance party of 3 to 6 players could play starting out at level 7. A single player would probably want to be at least level 8. This adventure is intended to be challenging and you may not be able to simply hack your way through the adventure at level 7. If you prefer a faster playing game that doesn't require so much careful planning and thought (and with less resetting of the game) then play with a slightly higher level character. The game should still be fun at level 9. This game will take 1 or 2 hours to play through.

A shadow has fallen across the world of Harthe. The arrival of a man, named Samuel, claiming to be a Veranite -- the lost race of kings blessed by the Creator of Harthe with divine power -- causes a stir in the country of Anvid. Could he really be a Veranite? Does he serve the Light, as he says, or is he a deceiver? 

Samuel gathers heroes across the land to do the will of the Virtues -- the spirits of good that he claims to talk to. You are one such hero. But the power of the Dark does not stand still. Who can resist it?

On your way to Anvid city to hunt down a Servant of Solanor named Tarnn Samuel has some heroes take a detour. The Virtues (Spirits of the Light) have contacted Samuel and say that Solanor is planning an attack near the border of Seradez. But what form will this attack take? Does Seradez, Anvid's old enemy, have anything to do with it? Could Samuel's suspicion that King Kalyl of Seradez is a Servant of Solanor be true?

This adventure is "DM-friendly." It alerts DMs of particular plot points and has the DM helper available to assist.

To learn more about The Light Reborn, please visit:
http://www.prism.net/bnielson/LightReborn.html

Credits:
Designed and Developed by: Bruce Nielson (bnielson@prism.net)
Testing: Christine Wheeler
Camera System: EG_Gestalt 
DM Helper: Dopple & Jhenne & Splith & Robert Bernavich & Archaegeo

We are always looking for more team members. If you'd like to join the team email Bruce at bnielson@prism.net

A note on The Light Reborn Series:
The Light Reborn is a PnP campaign game that was created original for T&T and GURPS. I converted it over to D&D 3E for Neverwinter Nights. The game world is somewhat different that your standard D&D game world, however. If you want to get the most out of your game experience, you should visit the web site listed above and read up on the world. There are also in game books that contain much of the background info that your character would realistically know. However, there are a few points that should probably be briefly covered here:
1) Humans are the dominant race. If possible, please play a human. The game will handle other races, but you get the best gaming experience if you play a human.
2) The adventure assumes that you are a good aligned character. You can play any alignment you wish, of course, but you'll get the best experience by playing good aligned.
3) Clerics and Paladins get their powers from Samuel Meladon, not from some god. If you play a Paladin or Cleric, there is no point in naming a deity as none of the D&D dieties exist in this world. There is, in fact, only one Creator in this world - not a patheon of gods.
These are just a few tips to help you with the game experience.

Another note: TLR 1 was story oriented. TLR 2 was puzzle, trick, trap oriented. TLR 3 was Final Fantasy-esque (i.e. really story oriented.) TLR 4 is meant to be action oriented. I'm trying to create adventures of all types and put them into a single campaign setting. Enjoy.


WARNING - Contains SPOILERS!
Extras: This adventure works especially well in a co-operative group. After you've played through once, go back and try it with a high charisma female in the party (CHR 15 or above). Also, let yourself be "killed" by the vampires and a little side quest will open up. 
Changes for version 1.08:
Henchmen can now level up to level 9 and they will have the same level as the player (instead of one level lower.) This will make the game easier in single player and it will make it so that the henchmen aren't a liability any more. (Or at least not as often.)

I also added journal entries for the kidnapping side quest if an NPC gets kidnapped by Kalyl. I found that many people had no idea what happened to their henchman because they didn't notice the kidnapping taking place during the heat of battle.

Changes for version 1.09:
Fixed the XP problem in multiplayer games. SharLet and Amlymn can now both appear in the game. Various other minor fixes.

Changes to Version 1.10: Fixed problem with henchman not respawning at the respawn point that broke due to Bioware changes in latest patch. Changed wedding clothes to be a wedding dress now that robes are available.

Changes to Version 1.12: Henchmen now "listen" to you. Added DMFI wands to the module.


Changes to Version 1.13: I broke some things with the DMFI wands and had to fix the script.

Changes to Version 1.14: I broke henchmen in version 1.12. They just died permenantly when they died, instead of respawning. I kept going reports every since XP2 came out about some bugs. I would try to create briefly, but couldn't. Finally, I sat down and thoroughly retested. I find a number of bugs introduced by Bioware's changes. I think I have them fixed. The Kalyl subquest was pretty well broken entirely. It's working now. The chessboard should no longer cause freezes or get you stuck in the arena.

Thanks,

Bruce Nielson